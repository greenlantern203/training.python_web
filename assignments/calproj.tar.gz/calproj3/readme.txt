Project Goals:

1.Django based calendar, where you can enter events.

2.The project can be run locally by running 'python manage.py runserver'

 
